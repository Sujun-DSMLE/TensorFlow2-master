Test for the tensorflow serving
