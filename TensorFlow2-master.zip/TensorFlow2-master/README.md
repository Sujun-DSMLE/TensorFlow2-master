# TensorFlow2
TensorFlow 2.0 Google Colab Notebook
